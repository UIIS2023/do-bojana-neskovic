package shapes;


public interface Moveable {
	
    void moveTo(int x, int y);
    
}